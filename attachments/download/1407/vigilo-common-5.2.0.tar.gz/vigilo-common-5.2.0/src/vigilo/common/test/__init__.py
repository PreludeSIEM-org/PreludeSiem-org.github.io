"""Tests unitaires de vigilo.common."""
