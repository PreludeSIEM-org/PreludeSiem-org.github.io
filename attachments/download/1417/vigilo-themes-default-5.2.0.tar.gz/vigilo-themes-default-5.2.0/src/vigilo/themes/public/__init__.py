# -*- coding: utf-8 -*-
"""Contient les fichiers statiques."""
