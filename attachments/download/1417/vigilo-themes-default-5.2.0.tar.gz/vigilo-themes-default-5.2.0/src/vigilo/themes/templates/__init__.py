# -*- coding: utf-8 -*-
"""Contient les templates."""
