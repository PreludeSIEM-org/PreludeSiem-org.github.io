UPDATE Prewikka_Version SET version="0.9.11";
ALTER TABLE Prewikka_User ADD COLUMN lang VARCHAR(32) NULL;
