##############
Interfaces web
##############

Les documents présentés ci-dessous sont applicables à l'ensemble des
interfaces web de Vigilo.

Documentation disponible :

.. toctree::
   :maxdepth: 2

   auth
   dev


.. : Le glossaire est inclus et ne doit donc pas apparaître dans la table
.. : des matières. Mais, on le référence dans une table des matières cachée
.. : afin d'éviter un avertissement de Sphinx.

.. toctree::
   :hidden:

   glossaire

.. *****************
.. Indexes et tables
.. *****************
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
