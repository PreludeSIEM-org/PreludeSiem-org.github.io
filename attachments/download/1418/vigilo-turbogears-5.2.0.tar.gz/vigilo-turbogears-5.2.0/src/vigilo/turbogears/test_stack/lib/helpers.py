# -*- coding: utf-8 -*-
"""Bibliothèque de modules outils"""
