# -*- coding: utf-8 -*-
# Copyright (C) 2011-2020 CS GROUP - France
# License: GNU GPL v2 <http://www.gnu.org/licenses/gpl-2.0.html>

"""
Module contenant les éléments relatifs à repoze.who
(frameworks d'authentification et d'autorisations).
"""
