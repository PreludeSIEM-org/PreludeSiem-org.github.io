# -*- coding: utf-8 -*-
"""Objets importés automatiquement dans les templates de TurboGears."""
