# -*- coding: utf-8 -*-
"""The vigigraph package"""
