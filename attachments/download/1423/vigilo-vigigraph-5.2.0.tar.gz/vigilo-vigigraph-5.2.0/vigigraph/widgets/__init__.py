# -*- coding: utf-8 -*-
"""Formulaires ToscaWidgets pour VigiGraph."""

