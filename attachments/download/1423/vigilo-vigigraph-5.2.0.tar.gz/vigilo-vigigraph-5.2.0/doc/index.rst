#########
VigiGraph
#########

VigiGraph est l'interface donnant accès à la métrologie (données de performance)
de l'ensemble des équipements et services du parc supervisé.

Documentation disponible :

.. toctree::
   :maxdepth: 2

   admin
   util


.. *****************
.. Indexes et tables
.. *****************
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
