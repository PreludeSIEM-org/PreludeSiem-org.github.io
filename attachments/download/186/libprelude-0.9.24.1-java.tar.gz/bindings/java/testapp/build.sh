javac -cp ../PreludeEasy.jar test.java
