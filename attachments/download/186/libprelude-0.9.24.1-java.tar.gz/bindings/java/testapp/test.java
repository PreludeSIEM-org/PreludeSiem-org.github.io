import com.prelude.easy.ClientEasy;
import com.prelude.easy.IDMEF;

public class test {
	static { System.loadLibrary("preludejava"); }

	private static ClientEasy c;

	public static void main(String argv[]){
		c= new ClientEasy("prelude-java-agent");
		try {
			c.Start();
			System.out.println("Creating IDMEF msg");
			IDMEF msg = new IDMEF();		
			System.out.println("Setting attribs...");
			msg.Set("alert.source(0).node.address(0).address","192.168.1.1");		
			msg.Set("alert.target(0).node.address(0).address","192.168.1.2");
			System.out.println("Sending msg...");
			c.SendIDMEF(msg);
		} catch (Exception exception){
			System.out.println(exception.toString());
			exception.printStackTrace();
		}
	}
}
