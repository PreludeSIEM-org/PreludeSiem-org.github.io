#!/bin/bash

make clean
rm PreludeEasy.cxx PreludeEasy.so PreludeEasy.o
make
g++ -I ../c++/include -c -I ../../src/include/ -I ../../src/libprelude-error/ -I../../ -I ../../libmissing/ -fpic PreludeEasy.cxx 
g++ -shared /usr/local/lib/libpreludecpp.so PreludeEasy.o -o libpreludejava.so
sudo cp libpreludejava.so /usr/local/lib/
sudo ldconfig
cp build/jar/PreludeEasy.jar ~/
