# -*- coding: utf-8 -*-
"""The vigirrd package"""
