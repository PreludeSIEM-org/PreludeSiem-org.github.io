#######
VigiRRD
#######

VigiRRD est l'interface d'interrogation des bases de données RRD contenant
les données de métrologie du parc supervisé.

Documentation disponible :

.. toctree::
   :maxdepth: 2

   admin


.. *****************
.. Indexes et tables
.. *****************
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
