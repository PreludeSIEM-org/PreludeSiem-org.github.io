###########################
Vigilo connector-syncevents
###########################

Le module connector-syncevents a pour fonction d'envoyer de re-synchroniser les
états de Nagios avec ceux de Vigilo dans le cas où des messages d'événements
auraient été perdus..

Documentation disponible :

.. toctree::
   :maxdepth: 2

   admin


.. *****************
.. Indexes et tables
.. *****************
.. 
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
