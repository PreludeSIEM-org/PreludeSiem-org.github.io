#######################
Vigilo connector-nagios
#######################

Le module connector-nagios a pour fonction d'échanger des messages de
supervision avec l'outil libre Nagios. Ces messages concernent l'état des
éléments du parc supervisé (hôtes ou services), les données de métrologie
récoltées sur les équipements, etc.

Documentation disponible :

.. toctree::
   :maxdepth: 2

   admin
   dev


.. *****************
.. Indexes et tables
.. *****************
.. 
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
