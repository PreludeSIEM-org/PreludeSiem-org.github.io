class UserError(Exception):
        pass
