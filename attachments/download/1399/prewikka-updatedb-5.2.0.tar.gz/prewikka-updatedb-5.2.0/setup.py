#!/usr/bin/env python

from setuptools import setup, find_packages


setup(
    name="prewikka-updatedb",
    version="5.2.0",
    maintainer="Prelude Team",
    maintainer_email="support.prelude@c-s.fr",
    url="https://www.prelude-siem.org",
    packages=find_packages(),
    entry_points={
        'prewikka.updatedb': [
            'prewikka = prewikkaupdatedb.prewikka',
            'prewikka.auth.dbauth = prewikkaupdatedb.dbauth',
            'prewikka.plugins.filter = prewikkaupdatedb.filter',
        ]
    }
)
