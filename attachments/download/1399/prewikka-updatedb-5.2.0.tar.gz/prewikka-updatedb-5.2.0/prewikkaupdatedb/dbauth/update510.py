from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("5.1", "0")
    branch = "5.2"
    version = "0"

    def run(self):
        self.query("""
DELETE FROM Prewikka_User_Group WHERE userid NOT IN (SELECT userid FROM Prewikka_User) OR groupid NOT IN (SELECT groupid FROM Prewikka_Group);
ALTER TABLE Prewikka_User_Group ADD FOREIGN KEY (userid) REFERENCES Prewikka_User(userid) ON DELETE CASCADE;
ALTER TABLE Prewikka_User_Group ADD FOREIGN KEY (groupid) REFERENCES Prewikka_Group(groupid) ON DELETE CASCADE;
        """)
