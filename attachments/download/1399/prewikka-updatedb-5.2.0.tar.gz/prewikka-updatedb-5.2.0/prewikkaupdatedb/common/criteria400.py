# Criteria JSON output for 4.0 -> 4.1 migration

def convert_criteria(criteria):
    token = "__prewikka_class__"
    if isinstance(criteria, list):
        return [convert_criteria(c) for c in criteria]

    elif isinstance(criteria, dict):
        if token in criteria and criteria[token][0] == "Criterion":
            left, operator, right = criteria[token][1]
            return {"__prewikka_class__": ["Criterion", {"left": convert_criteria(left),
                                                         "operator": operator,
                                                         "right": convert_criteria(right)}]}
        else:
            return dict((k, convert_criteria(v)) for k, v in criteria.items())

    else:
        return criteria
