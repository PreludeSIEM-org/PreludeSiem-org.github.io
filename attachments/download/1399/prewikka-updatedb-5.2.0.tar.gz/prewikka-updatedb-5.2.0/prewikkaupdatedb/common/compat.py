from prewikka import version


def get_version():
    major, minor, micro = version.__version_info__
    return int(major), int(minor), micro


def get_db_type(db):
    if get_version() >= (5, 1):
        return db.get_type()
    else:
        return db.getType()
