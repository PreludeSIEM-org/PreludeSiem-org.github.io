import json
import pkg_resources

from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("4.0", "0")
    branch = "4.1"
    version = "0"

    def run(self):
        self.query("""
CREATE TABLE Prewikka_Crontab (
    id BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    userid VARCHAR(32) NULL,
    schedule VARCHAR(32) NULL,
    ext_type VARCHAR(255) NULL,
    ext_id INTEGER NULL,
    base DATETIME NOT NULL,
    enabled TINYINT DEFAULT 1,
    runcnt  INTEGER DEFAULT 0,
    error TEXT NULL
) ENGINE=InnoDB;

CREATE TABLE Prewikka_History_Query (
    userid VARCHAR(32) NOT NULL,
    formid VARCHAR(255) NOT NULL,
    query TEXT NOT NULL,
    timestamp DATETIME NOT NULL
) ENGINE=InnoDB;
        """)
