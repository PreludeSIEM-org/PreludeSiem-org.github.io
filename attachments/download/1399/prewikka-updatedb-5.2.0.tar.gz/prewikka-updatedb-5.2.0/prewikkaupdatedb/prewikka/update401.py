from prewikkaupdatedb.prewikka.update400 import SQLUpdate as SQLUpdate400


class SQLUpdate(SQLUpdate400):
    type = "branch"
    from_branch = ("4.0", "1")
    branch = "4.1"
    version = "1"
