import json
import pkg_resources

from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("3.1", "0")
    branch = "4.0"
    version = "0"

    def run(self):
        entrypoints = [
            "prewikka.views",
            "prewikka.plugins",
            "prewikka.dataprovider.backend",
            "prewikka.dataprovider.type",
            "prewikka.auth",
            "prewikka.session",
            "prewikka.renderer.backend",
            "prewikka.renderer.type"
        ]

        for entrypoint in entrypoints:
            for i in pkg_resources.iter_entry_points(entrypoint):
                try:
                    plugin_class = i.load()
                except:
                    name = i.module_name
                else:
                    name = plugin_class.__module__

                fullname = "%s:%s" % (name, i.attrs[0])
                self.db.query("UPDATE Prewikka_Module_Registry SET module = %(new)s WHERE module = %(old)s",
                              new=fullname, old=name)

        self.db.modinfos_cache.clear()

        values = {}
        for userid, view, name, value in self.db.query("SELECT userid, view, name, value FROM Prewikka_User_Configuration"):
            values.setdefault((userid, view or "", name), []).append(value)

        for key, value in values.items():
            if key[2] not in ("aggregated_analyzer", "aggregated_classification", "aggregated_source", "aggregated_target", "alert.assessment.impact.completion", "alert.assessment.impact.severity", "alert.type", "alert.status", "selected_path"):
                values[key] = value[0]

        self.query("""
DROP TABLE IF EXISTS Prewikka_User_Configuration;
CREATE TABLE Prewikka_User_Configuration (
    userid VARCHAR(255) NOT NULL,
    view VARCHAR(32) NULL,
    name VARCHAR(255) NOT NULL,
    value VARCHAR(255) NULL,
    PRIMARY KEY(userid, view, name)
) ENGINE=InnoDB;
        """)

        self.db.query("INSERT INTO Prewikka_User_Configuration (userid, view, name, value) "
                      "VALUES %s", [(key[0], key[1], key[2], json.dumps(value)) for key, value in values.items()])
