from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("5.1", "0")
    branch = "5.2"
    version = "0"

    def run(self):
        anon = ('anonymous', '294de3557d9d00b3d2d8a1e6aab028cf')
        if self.db.query("SELECT 1 FROM Prewikka_Module_Registry WHERE module LIKE '%DBAuth'"):
            users = [(name, userid) for name, userid in self.db.query("SELECT name, userid FROM Prewikka_User")]
            if anon not in users:
                users.append(anon)

            groups = self.db.query("SELECT name, groupid FROM Prewikka_Group")
            user_perms = self.db.query("SELECT userid, permission FROM Prewikka_User_Permission INNER JOIN Prewikka_User USING (userid)")
            group_perms = self.db.query("SELECT groupid, permission FROM Prewikka_Group_Permission INNER JOIN Prewikka_Group USING (groupid)")

        else:
            users = [anon]
            groups = []
            user_perms = []
            group_perms = []

        self.query("""
UPDATE Prewikka_Module_Registry SET module = 'prewikka.plugins.filter:FilterPlugin' WHERE module = 'prewikka.views.filter.filter:FilterView';
UPDATE Prewikka_Module_Registry SET module = 'prewikka.auth.dbauth:DBAuth' WHERE module = 'prewikkapro.auth.dbauth.dbauth:DBAuth';


DROP TABLE IF EXISTS Prewikka_User_Permission;
DROP TABLE IF EXISTS Prewikka_User;

CREATE TABLE Prewikka_User (
    name VARCHAR(255) NOT NULL,
    userid VARCHAR(32) NOT NULL PRIMARY KEY
) ENGINE=InnoDB;

CREATE INDEX prewikka_user_index_name ON Prewikka_User (name);

%(insert_users)s


CREATE TABLE Prewikka_User_Permission (
    userid VARCHAR(32) NOT NULL,
    permission VARCHAR(32) NOT NULL,
    PRIMARY KEY (userid, permission),
    FOREIGN KEY (userid) REFERENCES Prewikka_User(userid) ON DELETE CASCADE
) ENGINE=InnoDB;

%(insert_user_perms)s


DROP TABLE IF EXISTS Prewikka_Group_Permission;
DROP TABLE IF EXISTS Prewikka_Group;


CREATE TABLE Prewikka_Group (
    name VARCHAR(255) NOT NULL,
    groupid VARCHAR(32) NOT NULL PRIMARY KEY
) ENGINE=InnoDB;

CREATE INDEX prewikka_group_index_name ON Prewikka_Group (name);

%(insert_groups)s


CREATE TABLE Prewikka_Group_Permission (
    groupid VARCHAR(32) NOT NULL,
    permission VARCHAR(32) NOT NULL,
    PRIMARY KEY (groupid, permission),
    FOREIGN KEY (groupid) REFERENCES Prewikka_Group(groupid) ON DELETE CASCADE
) ENGINE=InnoDB;

%(insert_group_perms)s


DELETE FROM Prewikka_Session WHERE userid NOT IN (SELECT userid FROM Prewikka_User);
ALTER TABLE Prewikka_Session ADD FOREIGN KEY (userid) REFERENCES Prewikka_User(userid) ON DELETE CASCADE;


DELETE FROM Prewikka_User_Configuration WHERE userid NOT IN (SELECT userid FROM Prewikka_User);
ALTER TABLE Prewikka_User_Configuration ADD FOREIGN KEY (userid) REFERENCES Prewikka_User(userid) ON DELETE CASCADE;


DELETE FROM Prewikka_Crontab WHERE userid NOT IN (SELECT userid FROM Prewikka_User);
ALTER TABLE Prewikka_Crontab ADD FOREIGN KEY (userid) REFERENCES Prewikka_User(userid) ON DELETE CASCADE;


DELETE FROM Prewikka_History_Query WHERE userid NOT IN (SELECT userid FROM Prewikka_User);
ALTER TABLE Prewikka_History_Query ADD FOREIGN KEY (userid) REFERENCES Prewikka_User(userid) ON DELETE CASCADE;
        """ % {
            "insert_users": "INSERT INTO Prewikka_User (name, userid) VALUES %s;" % self.db.escape(users) if users else "",
            "insert_groups": "INSERT INTO Prewikka_Group (name, groupid) VALUES %s;" % self.db.escape(groups) if groups else "",
            "insert_user_perms": "INSERT INTO Prewikka_User_Permission (userid, permission) VALUES %s;" % self.db.escape(user_perms) if user_perms else "",
            "insert_group_perms": "INSERT INTO Prewikka_Group_Permission (groupid, permission) VALUES %s;" % self.db.escape(group_perms) if group_perms else "",
        })
