from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("5.0", "0")
    branch = "5.1"
    version = "0"

    def run(self):
        self.query("""
ALTER TABLE Prewikka_Filter ADD category VARCHAR(64) NULL;
        """)
