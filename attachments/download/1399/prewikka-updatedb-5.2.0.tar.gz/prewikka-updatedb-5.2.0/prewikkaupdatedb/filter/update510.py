from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("5.1", "0")
    branch = "5.2"
    version = "0"

    def run(self):
        self.query("""
DELETE FROM Prewikka_Filter WHERE userid NOT IN (SELECT userid FROM Prewikka_User);
ALTER TABLE Prewikka_Filter ADD FOREIGN KEY (userid) REFERENCES Prewikka_User(userid) ON DELETE CASCADE;
        """)
