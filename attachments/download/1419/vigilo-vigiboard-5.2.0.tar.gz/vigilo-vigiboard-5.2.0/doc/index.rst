#########
VigiBoard
#########

VigiBoard est l'interface de visualisation des événements de Vigilo.

Documentation disponible :

.. toctree::
   :maxdepth: 2

   admin
   dev
   util


.. *****************
.. Indexes et tables
.. *****************
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
