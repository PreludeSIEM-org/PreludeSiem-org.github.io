**********************
Guide de développement
**********************



Annexes
=======

.. include:: ../../turbogears/doc/glossaire.rst

.. vim: set tw=79 :
