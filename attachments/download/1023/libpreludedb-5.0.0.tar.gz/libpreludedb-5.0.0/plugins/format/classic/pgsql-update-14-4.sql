UPDATE _format SET version='14.4'; 
ALTER TABLE Prelude_AdditionalData ALTER COLUMN data SET NOT NULL;
