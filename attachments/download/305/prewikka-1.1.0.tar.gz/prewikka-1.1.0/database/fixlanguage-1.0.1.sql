UPDATE prewikka.Prewikka_User SET lang='de_DE' WHERE lang='de';
UPDATE prewikka.Prewikka_User SET lang='es_ES' WHERE lang='es';
UPDATE prewikka.Prewikka_User SET lang='en_GB' WHERE lang='en';
UPDATE prewikka.Prewikka_User SET lang='fr_FR' WHERE lang='fr';
UPDATE prewikka.Prewikka_User SET lang='pl_PL' WHERE lang='pl';
UPDATE prewikka.Prewikka_User SET lang='ru_RU' WHERE lang='ru';
