# -*- coding: utf-8 -*-
"""Package contenant les règles de corrélation."""
