# -*- coding: utf-8 -*-
"""Les différents composants du corrélateur"""