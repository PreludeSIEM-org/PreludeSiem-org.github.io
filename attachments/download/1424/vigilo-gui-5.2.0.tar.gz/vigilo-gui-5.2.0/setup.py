#!/usr/bin/env python

# Copyright (C) 2018-2020 CS GROUP - France. All Rights Reserved.
# Author: Camille Gardet <camille.gardet@c-s.fr>

import glob
import os
import stat

from setuptools import setup, find_packages

from distutils.dist import Distribution
from distutils.command.install import install
from distutils.command.build import build as _build


class MyDistribution(Distribution):
    def __init__(self, attrs):
        self.conf_files = {}
        self.closed_source = os.path.exists("PKG-INFO")
        Distribution.__init__(self, attrs)


class my_install(install):
    def finalize_options(self):
        # if no prefix is given, configuration should go to /etc or in {prefix}/etc otherwise
        if self.prefix:
            self.conf_prefix = self.prefix + "/etc/prewikka"
        else:
            self.conf_prefix = "/etc/prewikka"

        install.finalize_options(self)

    def install_conf(self):
        self.mkpath((self.root or "") + self.conf_prefix + "/conf.d")
        for dest_dir, patterns in self.distribution.conf_files.items():
            for pattern in patterns:
                for f in glob.glob(pattern):
                    dest = (self.root or "") + self.conf_prefix + "/" + dest_dir + "/" + os.path.basename(f)
                    if os.path.exists(dest):
                        dest += "-dist"
                    self.copy_file(f, dest)

    def run(self):
        os.umask(0o22)
        self.install_conf()
        install.run(self)

        os.chmod((self.root or "") + self.conf_prefix, 0o755)

        if not self.dry_run:
            for filename in self.get_outputs():
                if filename.find(".conf") != -1:
                    continue
                mode = os.stat(filename)[stat.ST_MODE]
                mode |= 0o44
                if mode & 0o100:
                    mode |= 0o11
                os.chmod(filename, mode)


class build(_build):
    sub_commands = [('compile_catalog', None)] + _build.sub_commands


setup(
    name="vigilo-gui",
    version="5.2.0",
    maintainer="Vigilo Team",
    maintainer_email="support.vigilo@csgroup.eu",
    url="https://www.vigilo-nms.com",
    packages=find_packages(),
    setup_requires=['Babel'],
    install_requires=['prewikka'],
    entry_points={
        'prewikka.dataprovider.backend': [
            'VigiloAlarm = vigilogui.dataprovider.plugins.alarm.vigilo:VigiloAlarmPlugin',
        ],
        'prewikka.dataprovider.type': [
            'Alarm = vigilogui.dataprovider.alarm:AlarmAPI',
        ],
        'prewikka.plugins': [
            'MetrologyPlugin = vigilogui.plugins.metrology:MetrologyPlugin',
        ],
        'prewikka.session': [
            'LoginVigilo = vigilogui.session.loginvigilo:LoginVigiloSession',
        ],
        'prewikka.views': [
            'AlarmDataSearch = vigilogui.views.datasearch.alarm:AlarmDataSearch',
            'AlarmDetail = vigilogui.views.alarms:AlarmDetail',
            'AlarmStats = vigilogui.views.statistics.alarmstats:AlarmStats',
            'MetrologyView = vigilogui.views.statistics.metrology:MetrologyView',
            'VigiloWarning = vigilogui.plugins.warning:Warning',
        ],
    },
    package_data={
        '': [
            "htdocs/images/*.*",
            "htdocs/css/*.css",
            "htdocs/js/*.js",
            "templates/*.mak",
            "locale/*.pot",
            "locale/*/LC_MESSAGES/*.mo"
        ],
    },
    conf_files={
        "": [
            "conf/vigilo.conf",
            "conf/menuvigilo.yml"
        ],
        "conf.d": [
            "conf/plugins/*.conf"
        ],
    },
    cmdclass={
        'install': my_install,
        'build': build
    },
    distclass=MyDistribution,
    message_extractors={
        'vigilogui': [
            ('**.py', 'python', None),
            ('**/templates/*.mak', 'mako', None)
        ]
    }
)
