# -*- coding: utf-8 -*-
# Copyright (C) 2019-2020 CS GROUP - France. All Rights Reserved.
# Author: Antoine Luong <antoine.luong@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

from __future__ import absolute_import, division, print_function, unicode_literals

import requests

from prewikka import database, pluginmanager, utils
from vigilogui import version


class MetrologyError(Exception):
    pass


class MetrologyPlugin(pluginmanager.PluginBase):
    plugin_name = "Metrology API"
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_version = version.__version__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Plugin to query metrology data")
    plugin_locale = version.__locale__

    def __init__(self):
        self._auth_url = env.config.metrology.auth_url
        self._export_url = env.config.metrology.export_url
        self._cookie_name = env.config.metrology.get("cookie_name", "authtkt")

        # FIXME: use the Database object created by the dataprovider
        settings = {"host": "localhost", "name": "vigilo", "user": "vigilo", "type": "pgsql"}
        settings.update(env.config.alarm)

        self._db = database.Database(settings)
        self._session = requests.Session()

        pluginmanager.PluginBase.__init__(self)

    def get_metrology_data(self, params):
        env.request.user.check(N_("METROLOGY_VIEW"))

        cookie = env.request.web.input_cookie.get(self._cookie_name)
        if not cookie:
            raise MetrologyError("Cookie not found")

        r = self._session.get(self._export_url % utils.url.quote(params["host"].encode("utf-8")), params=params, cookies={self._cookie_name: cookie.value})
        if r.ok:
            return r.text
        else:
            raise MetrologyError("Error %d" % r.status_code)

    def get_hosts(self, term):
        return [name for (name,) in self._db.query("SELECT name FROM vigilo_host WHERE name LIKE %s LIMIT 10", "%%%s%%" % term)]

    def get_graphs(self, host, term=None):
        query = ("SELECT DISTINCT(g.name) FROM vigilo_graph AS g "
                 "JOIN vigilo_graphperfdatasource AS gpds ON g.idgraph = gpds.idgraph "
                 "JOIN vigilo_perfdatasource AS pds ON gpds.idperfdatasource = pds.idperfdatasource "
                 "JOIN vigilo_host AS h ON pds.idhost = h.idhost "
                 "WHERE h.name = %s")
        args = [host]

        if term:
            query += " AND LOWER(g.name) LIKE %s"
            args.append("%%%s%%" % term.lower())

        query += " ORDER BY g.name"

        return [graph for (graph,) in self._db.query(query, *args)]

    def get_graph_info(self, host, graph):
        rows = self._db.query("SELECT vlabel FROM vigilo_graph WHERE name = %s", graph)
        if not rows:
            raise MetrologyError("Graph not found")

        ylabel = rows[0][0]
        rows = self._db.query(
            "SELECT pds.name, label, factor FROM vigilo_perfdatasource AS pds "
            "JOIN vigilo_graphperfdatasource AS gpds ON pds.idperfdatasource = gpds.idperfdatasource "
            "JOIN vigilo_graph AS g ON gpds.idgraph = g.idgraph "
            "JOIN vigilo_host AS h ON pds.idhost = h.idhost "
            "WHERE g.name = %s AND h.name = %s", graph, host
        )
        categories = {}
        for name, label, factor in rows:
            categories[name] = utils.AttrObj(label=label, factor=float(factor))

        return ylabel, categories
