# -*- coding: utf-8 -*-
# Copyright (C) 2019-2020 CS GROUP - France. All Rights Reserved.
# Author: Antoine Luong <antoine.luong@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""Alarm detail view."""

from __future__ import absolute_import, division, print_function, unicode_literals

import functools
import pkg_resources

from prewikka import error, localization, template, view
from prewikka.dataprovider import Criterion
from prewikka.utils.viewhelpers import GridAjaxResponse

from vigilogui import version


class AlarmDetail(view.View):
    plugin_name = "Detailed alarm"
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_version = version.__version__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Detailed alarm page")
    plugin_locale = version.__locale__
    plugin_htdocs = (("alarms", pkg_resources.resource_filename(__name__, 'htdocs')),)

    @view.route("/alarms/<int:alarmid>", permissions=[N_("ALARM_VIEW")])
    def detail(self, alarmid):
        paths = [
            "alarm.initial_state.name",
            "alarm.peak_state.name",
            "alarm.current_state.name",
            "alarm.first_occurrence",
            "alarm.last_occurrence",
            "alarm.message",
            "alarm.cause.host.name",
            "alarm.cause.host.address",
            "alarm.cause.service",
            "alarm.priority",
            "alarm.occurrences",
            "alarm.acknowledgment",
        ]
        rows = env.dataprovider.query(paths, Criterion("alarm.alarmid", "=", alarmid))
        if not rows:
            raise error.PrewikkaUserError(N_("Invalid alarm"), N_("Specified alarm does not exist"))

        alarm = {path.split(".", 1)[-1]: value for path, value in zip(paths, rows[0])}
        alarm["alarmid"] = alarmid

        alarm["impact.service.name"] = []
        for (service,) in env.dataprovider.query(["alarm.impact.service.name"], Criterion("alarm.alarmid", "=", alarmid)):
            if service:
                alarm["impact.service.name"].append(service)

        history_url = None
        views = env.viewmanager.get(datatype="alarm", keywords=["listing"])
        if views:
            criteria = Criterion("alarm.cause.host.name", "=", alarm["cause.host.name"]) & Criterion("alarm.cause.service", "=", alarm["cause.service"])
            history_url = views[-1].make_url(criteria=criteria, show_closed_alarms=1)

        return template.PrewikkaTemplate(__name__, "templates/alarmdetails.mak").render(
            alarm=alarm,
            history_url=history_url
        )

    @view.route("/alarms/<int:alarmid>/history")
    def history(self, alarmid):
        page = int(env.request.parameters["page"])
        nb_rows = int(env.request.parameters["rows"])

        paths = ["alarm.history.time", "alarm.history.author", "alarm.history.type", "alarm.history.value", "alarm.history.message"]
        results = env.dataprovider.query(paths, Criterion("alarm.alarmid", "=", alarmid), limit=nb_rows, offset=(page - 1) * nb_rows)
        total = env.dataprovider.query(["count(alarm.history.time)"], Criterion("alarm.alarmid", "=", alarmid))[0][0]

        rows = []
        for date, user, typ, value, message in results:
            rows.append({
                "date": localization.format_datetime(date),
                "user": user,
                "type": typ,
                "value": value,
                "message": message
            })

        return GridAjaxResponse(rows, total)

    @view.route("/alarms/<int:alarmid>/masked_events")
    def masked_events(self, alarmid):
        cause_id = env.dataprovider.query(["alarm.cause.id"], Criterion("alarm.alarmid", "=", alarmid))[0][0]

        page = int(env.request.parameters["page"])
        nb_rows = int(env.request.parameters["rows"])

        paths = [
            "alarm.last_occurrence",
            "alarm.current_state.name",
            "alarm.cause.host.name",
            "alarm.cause.service",
            "alarm.message"
        ]
        criteria = Criterion("alarm.alarmid", "=", alarmid) & Criterion("alarm.masked_event.id", "!=", cause_id)
        results = env.dataprovider.query(["alarm.masked_event.id"], criteria, limit=nb_rows, offset=(page - 1) * nb_rows)
        if not results:
            return GridAjaxResponse([], 0)

        total = env.dataprovider.query(["count(alarm.masked_event.id)"], criteria)[0][0]
        criteria = functools.reduce(lambda x, y: x | y, (Criterion("alarm.eventid", "=", eventid) for (eventid,) in results))
        results = env.dataprovider.query(paths, criteria)

        rows = []
        for date, state, host, service, message in results:
            rows.append({
                "date": localization.format_datetime(date),
                "state": state,
                "host": host,
                "service": service,
                "message": message
            })

        return GridAjaxResponse(rows, total)
