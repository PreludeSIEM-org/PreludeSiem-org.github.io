# -*- coding: utf-8 -*-
# Copyright (C) 2019-2020 CS GROUP - France. All Rights Reserved.
# Author: François Poirotte <francois.poirotte@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

from __future__ import absolute_import, division, print_function, unicode_literals

from copy import deepcopy
from prewikka import hookmanager, view
from prewikka.dataprovider import Criterion
from prewikka.views.statistics import statistics
from vigilogui import version


_DEFAULT_GRAPHS = [
    {
        "title": N_("Alarm chronology by initial state"),
        "category": "chronology",
        "type": "timeline",
        "path": "alarm.initial_state.name",
        "limit": -1,
        "description": N_("This graph shows the evolution of the number of alarms grouped by initial state.")
    },
    {
        "title": N_("Top {limit} most failing hosts"),
        "category": "diagram",
        "type": "bar",
        "criteria": Criterion("alarm.current_state.name", "!=", "OK") & Criterion("alarm.current_state.name", "!=", "UP"),
        "path": "alarm.cause.host.name",
        "description": N_("This graph shows the hosts with currently the most alarms.")
    },
    {
        "title": N_("Top {limit} most failing services"),
        "category": "diagram",
        "type": "bar",
        "criteria": Criterion("alarm.current_state.name", "!=", "OK") | Criterion("alarm.current_state.name", "!=", "UP"),
        "path": "alarm.cause.service",
        "description": N_("This graph shows the services with currently the most alarms.")
    },
    {
        "title": N_("Alarm acknowledgments"),
        "category": "diagram",
        "type": "pie",
        "path": "alarm.acknowledgment",
        "description": N_("This graph shows the repartition of the alarms' acknowledgments.")
    },
    {
        "title": N_("Alarm states"),
        "category": "diagram",
        "type": "pie",
        "path": "alarm.current_state.name",
        "description": N_("This graph shows the repartition of the alarms' states.")
    },
    {
        "title": N_("Alarm priorities"),
        "category": "diagram",
        "type": "pie",
        "path": "alarm.priority",
        "description": N_("This graph shows the repartition of the alarms' priorities.")
    }
]


class AlarmStats(statistics.StaticStats):
    plugin_name = "Statistics: Alarms"
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_version = version.__version__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Statistics page about alarms")
    plugin_locale = version.__locale__
    plugin_require = ["prewikka.views.statistics:Statistics"]

    _DEFAULT_ATTRIBUTES = {
        "global": {"width": 6}
    }

    _PREDEFINED_GRAPHS = deepcopy(_DEFAULT_GRAPHS)

    def __init__(self):
        env.dataprovider.check_datatype("alarm")
        statistics.StaticStats.__init__(self)

        hookmanager.register("HOOK_DASHBOARD_DEFAULT_GRAPHS", _DEFAULT_GRAPHS)

    @view.route("/statistics/alarms", methods=["GET", "POST"], menu=(N_("Statistics"), N_("Alarms")), permissions=[N_("ALARM_VIEW")], datatype="alarm", help="#alarmstats")
    def render(self):
        return self.draw()
