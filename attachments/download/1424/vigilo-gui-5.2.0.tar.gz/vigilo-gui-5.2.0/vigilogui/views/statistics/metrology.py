# -*- coding: utf-8 -*-
# Copyright (C) 2019-2020 CS GROUP - France. All Rights Reserved.
# Author: Antoine Luong <antoine.luong@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

from __future__ import absolute_import, division, print_function, unicode_literals

import collections
import csv
import datetime
import xlwt
from xlwt.Utils import quote_sheet_name

from prewikka import error, hookmanager, localization, mainmenu, resource, statistics, template, utils, view
from prewikka.views.statistics.statistics import StaticStats, StatsParameters
from vigilogui import version
from vigilogui.plugins.metrology import MetrologyError


class MetrologyParameters(StatsParameters):
    def register(self):
        StatsParameters.register(self)
        self.optional("host", text_type, save=True)


class MetrologyView(StaticStats):
    plugin_name = "Metrology"
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_version = version.__version__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Metrology charts plugin")
    plugin_locale = version.__locale__
    plugin_require = ["vigilogui.plugins.metrology:MetrologyPlugin", "prewikka.views.statistics:Statistics"]

    _PREDEFINED_GRAPHS = []

    # The (custom) palette is limited to 48 colours.
    _COLOR_PALETTE = {
        "dark": (0x5c, 0xb8, 0x5c),
        "light": (0x8c, 0xe8, 0x8c),
    }

    def __init__(self):
        hookmanager.register("HOOK_CHART_CLASSES", ("metrology", MetrologyChart))
        StaticStats.__init__(self)

        paths = ["alarm.cause.host.name"]
        env.linkmanager.add_link(N_("Metrology"), paths, lambda x: url_for("MetrologyView.stats", host=x))

    @view.route("/metrology/hosts", permissions=[N_("METROLOGY_VIEW")])
    def hosts(self):
        term = env.request.parameters.get("term", "")
        return env.plugins["MetrologyPlugin"].get_hosts(term)

    @view.route("/metrology/graphs", permissions=[N_("METROLOGY_VIEW")])
    def graphs(self):
        host = env.request.parameters.get("host")
        term = env.request.parameters.get("term", "")
        return env.plugins["MetrologyPlugin"].get_graphs(host, term)

    @view.route("/metrology/stats", permissions=[N_("METROLOGY_VIEW")], methods=["GET", "POST"],
                menu=(N_("Statistics"), N_("Metrology")), parameters=MetrologyParameters)
    def render(self):
        host = env.request.parameters.get("host", "localhost")
        self._prepare_charts(host)
        dataset = template.PrewikkaTemplate(__name__, "templates/metrologystats.mak").dataset()
        data = self.setup(dataset)
        if data:
            return data

        menu = template.PrewikkaTemplate(__name__, "templates/metrologymenu.mak").dataset(host=host)

        return view.ViewResponse(dataset.render(), menu=mainmenu.HTMLMainMenu(menu_extra=[resource.HTMLSource(menu.render())]))

    @view.route("/metrology/stats/<host>", permissions=[N_("METROLOGY_VIEW")], methods=["GET", "POST"])
    def stats(self, host):
        self._prepare_charts(host)
        dataset = template.PrewikkaTemplate(__name__, "templates/metrologyembeddedstats.mak").dataset(
            modal_title=_("Metrology for %s") % host,
            url_render=url_for("MetrologyView.stats", host=host),
            typestats="metrology"
        )
        data = self.setup(dataset)
        if data:
            return data

        dataset["options"].update({
            "current_url": dataset["url_render"],
            "selector": ".metrologystats"
        })

        return dataset.render()

    def _prepare_charts(self, host):
        graphs = env.plugins["MetrologyPlugin"].get_graphs(host)
        self.chart_infos = [{
            "category": "metrology",
            "type": "timeline",
            "title": graph,
            "host": host,
            "graphtemplate": graph,
            "linkmode": None,
            "width": 6
        } for graph in graphs]

    @staticmethod
    def _quote_formula_arg(arg):
        return '"%s"' % arg.replace('"', '""')

    @staticmethod
    def _pick_sheet_name(graph, sheetnames):
        if graph.startswith("'"):
            graph = graph[1:]
        if graph.endswith("'"):
            graph = graph[:-1]
        for c in "[]:\\?/*\x00":
            graph = graph.replace(c, '_')

        graph = graph[:31]
        if graph and graph not in sheetnames:
            return graph

        # Replace the last 3 characters with a counter
        graph = graph[:28]
        for i in range(2, 1000):
            tmp = "%s%03d" % (graph, i)
            if tmp not in sheetnames:
                return tmp
        raise error.PrewikkaUserError(N_("Export error"), N_("Could not create a valid worksheet name"))

    @view.route("/metrology/export")
    def export(self):
        host = env.request.parameters["host"]
        workbook = xlwt.Workbook()
        sheetnames = set([_("Summary")])

        # Initialize the palette for later
        for index, (name, color) in enumerate(self._COLOR_PALETTE.items()):
            xlwt.add_palette_colour(name, 0x10 + index)
            workbook.set_colour_RGB(0x10 + index, *color)

        header_styles = xlwt.easyxf('font: colour white, height 240, bold on; '
                                    'pattern: pattern solid, fore_colour dark')
        shade0_styles = xlwt.easyxf('pattern: pattern solid, fore_colour light')
        shade1_styles = xlwt.easyxf('pattern: pattern solid, fore_colour white')

        summary = workbook.add_sheet(_("Summary"))
        summary.col(0).width = 256 * 35
        summary.col(1).width = 256 * 100
        summary.write_merge(0, 0, 0, 1, _("Information"), header_styles)
        summary.write(1, 0, _("Host"), shade0_styles)
        summary.write(1, 1, host)
        summary.write(2, 0, _("Start"), shade0_styles)
        summary.write(2, 1, localization.format_datetime(env.request.menu.start))
        summary.write(3, 0, _("End"), shade0_styles)
        summary.write(3, 1, localization.format_datetime(env.request.menu.end))
        # Skip two lines
        summary.write(6, 0, _("Dataset"), header_styles)
        summary.write(6, 1, _("Description"), header_styles)

        for graph in env.plugins["MetrologyPlugin"].get_graphs(host):
            params = {
                "host": host,
                "graphtemplate": graph,
                "start": utils.timeutil.get_timestamp_from_datetime(env.request.menu.start),
                "end": utils.timeutil.get_timestamp_from_datetime(env.request.menu.end)
            }
            try:
                data = env.plugins["MetrologyPlugin"].get_metrology_data(params)
            except MetrologyError:
                continue

            sheetname = self._pick_sheet_name(graph, sheetnames)
            style = shade0_styles if len(sheetnames) % 2 else shade1_styles
            summary.write(len(sheetnames) + 6, 0, xlwt.Formula('HYPERLINK("#{0}!A1", {1})'.format(
                quote_sheet_name(sheetname), self._quote_formula_arg(sheetname))), style)
            summary.write(len(sheetnames) + 6, 1, xlwt.Formula('HYPERLINK("#{0}!A1", {1})'.format(
                quote_sheet_name(sheetname), self._quote_formula_arg(graph))), style)
            sheetnames.add(sheetname)

            sheet = workbook.add_sheet(sheetname)
            for row, values in enumerate(csv.reader(data.splitlines(), delimiter=b";")):
                for col, value in enumerate(values):
                    # Use a dark tone for the header and alternate stripes
                    # for the other rows.
                    if not row:
                        style = header_styles
                    else:
                        style = shade0_styles if row % 2 else shade1_styles
                    sheet.write(row, col, value, style)

            # Try to set an optimal width for every column.
            widths = {0: 15, 1: 40}
            for i in range(col + 1):
                sheet.col(i).width = 256 * widths.get(i, 20)

        if len(sheetnames) <= 1:
            raise error.PrewikkaUserError(N_("Export error"), N_("No graphs could be retrieved"))

        today = datetime.date.today()
        with utils.mkdownload("metrology_%s_%s.xls" % (host, today)) as dl:
            workbook.save(dl)

        return dl


class MetrologyChart(statistics.ChronologyChart):
    _number_of_points = 1000

    @staticmethod
    def _get_default_value(datatype):
        return None

    def _get_series(self, query, selection, date_precision):
        self._default_view = None

        params = {
            "host": self.options["host"],
            "graphtemplate": self.options["graphtemplate"],
            "start": utils.timeutil.get_timestamp_from_datetime(self._menu.start),
            "end": utils.timeutil.get_timestamp_from_datetime(self._menu.end)
        }
        try:
            data = env.plugins["MetrologyPlugin"].get_metrology_data(params)
            ylabel, categories = env.plugins["MetrologyPlugin"].get_graph_info(self.options["host"], self.options["graphtemplate"])
        except MetrologyError:
            return {}

        self.options["ylabel"] = ylabel.split(", ")

        names = []
        out = collections.OrderedDict()
        for i, values in enumerate(csv.reader(data.splitlines(), delimiter=b";")):
            if i == 0:
                names = values[2:]
                continue

            try:
                timestamp = float(values[0])
            except ValueError:
                return {}

            # Convert the UTC timestamp to a date in the user's timezone
            date = datetime.datetime.utcfromtimestamp(timestamp).replace(tzinfo=utils.timeutil.tzutc())
            datetuple = date.astimezone(env.request.user.timezone).timetuple()

            for name, value in zip(names, values[2:]):
                category = categories[name]
                try:
                    value = float(value) * category.factor
                except ValueError:
                    value = None
                out.setdefault((category.label,), {})[datetuple[:date_precision]] = value

        return out
