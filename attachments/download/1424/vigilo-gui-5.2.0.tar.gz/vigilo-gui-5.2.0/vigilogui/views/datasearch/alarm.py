# -*- coding: utf-8 -*-
# Copyright (C) 2019-2020 CS GROUP - France. All Rights Reserved.
# Author: François Poirotte <francois.poirotte@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""DataSearch alarm view."""

from __future__ import absolute_import, division, print_function, unicode_literals

import collections
import functools

from prewikka import hookmanager, localization, resource, response, template, utils, view
from prewikka.dataprovider import Criterion
from prewikka.localization import format_datetime
from prewikka.views.datasearch import datasearch

from vigilogui import version


class AlarmFormatter(datasearch.Formatter):
    _STATE_CLASSES = {
        "CRITICAL": "btn-danger",
        "DOWN": "btn-danger",
        "OK": "btn-success",
        "UNKNOWN": "btn-default2",
        "UNREACHABLE": "btn-default2",
        "UP": "btn-success",
        "WARNING": "btn-warning",
    }

    def format(self, finfo, root, obj):
        if finfo.path == "alarm.last_occurrence":
            href = url_for("AlarmDetail.detail", alarmid=root[0])  # alarmid is the first field to be fetched
            return resource.HTMLNode("a", format_datetime(obj), href=href, title=_("See alarm details"), **{"data-toggle": "tooltip", "data-container": "#main"})

        return datasearch.Formatter.format(self, finfo, root, obj)

    def format_value(self, field, value):
        if field in ("current_state.name", "initial_state.name", "peak_state.name"):
            return self._format_state(field, value)

        if field == "duration":
            return self._format_duration(field, value)

        if field == "acknowledgment":
            return self._format_acknowledgment(field, value)

        return datasearch.Formatter.format_value(self, field, value)

    def _format_state(self, field, value):
        node = resource.HTMLNode("span", resource.HTMLNode("span", value[0]), _class="selectable", **{"data-field": field, "data-value": value})
        node._extra = {"_classes": self._STATE_CLASSES.get(value, "btn-default")}
        return node

    def _format_duration(self, field, value):
        return resource.HTMLNode("span", localization.format_value(value))

    def _format_acknowledgment(self, field, value):
        statuses = env.dataprovider.get_path_info("alarm.acknowledgment").value_accept
        return resource.HTMLNode("span", resource.HTMLNode("span", _(statuses[value].label)), _class="selectable", **{"data-field": field, "data-value": value})


class AlarmQueryParser(datasearch.QueryParser):
    def __init__(self, query, parent, groupby=[], orderby=[], offset=0, limit=50):
        datasearch.QueryParser.__init__(self, query, parent, groupby, orderby, offset, limit)

        if not env.request.parameters["show_closed_alarms"]:
            self.criteria += Criterion("alarm.acknowledgment", "!=", 2) | (
                Criterion("alarm.current_state.name", "!=", "OK") &
                Criterion("alarm.current_state.name", "!=", "UP")
            )
            self.all_criteria = self.criteria + env.request.menu.get_criteria()

    def _query(self):
        ret = env.dataprovider.query(self.get_paths(), self.all_criteria, limit=self.limit, offset=self.offset, type=self.type)
        ret.total = env.dataprovider.query(["count(1)"], self.all_criteria, type=self.type)[0][0]
        return ret

    def add_order(self, field, order="asc"):
        field = field.replace("name", "rank") if field.endswith("state.name") else field
        return datasearch.QueryParser.add_order(self, field, order)


class AlarmParameters(datasearch.DataSearchParameters):
    def register(self):
        datasearch.DataSearchParameters.register(self)
        self.optional("show_closed_alarms", int, default=0, save=True)


class AlarmDataSearch(datasearch.DataSearch):
    plugin_name = "DataSearch: Alarms"
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_version = version.__version__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Alarm listing page")

    view_permissions = [N_("ALARM_VIEW")]
    view_parameters = AlarmParameters

    type = "alarm"
    name = "alarms"
    section = N_("Alarms")
    tabs = (N_("Alarms"), N_("Aggregated alarms"))
    formatter = AlarmFormatter
    query_parser = AlarmQueryParser
    criterion_config_default = "criterion"
    sort_path_default = "current_state.rank"
    groupby_default = ["cause.host.name"]
    default_columns = collections.OrderedDict([
        ("alarm.alarmid", N_("ID")),
        ("alarm.initial_state.name", "I"),
        ("alarm.peak_state.name", "W"),
        ("alarm.current_state.name", "C"),
        ("alarm.first_occurrence", N_("First occurrence")),
        ("alarm.last_occurrence", N_("Last occurrence")),
        ("alarm.duration", N_("Duration")),
        ("alarm.cause.host.name", N_("Host")),
        ("alarm.cause.service", N_("Service")),
        ("alarm.priority", N_("Priority")),
        ("alarm.occurrences", N_("Occurrences")),
        ("alarm.message", N_("Message")),
        ("alarm.acknowledgment", N_("Acknowledgment")),
        ("alarm.cause.host.address", N_("Address"))
    ])
    lucene_search_fields = ["cause.host.name", "cause.service", "message"]
    _hidden_fields = ["alarm.alarmid", "alarm.cause.host.address", "alarm.first_occurrence", "alarm.initial_state", "alarm.peak_state"]

    def _get_fields(self):
        return self._main_fields

    def _get_column_property(self, field, pi):
        header_tooltips = {
            "alarm.current_state.name": N_("Current state"),
            "alarm.initial_state.name": N_("Initial state"),
            "alarm.peak_state.name": N_("Worst state"),
        }
        widths = {
            "alarm.current_state.name": 10,
            "alarm.initial_state.name": 10,
            "alarm.peak_state.name": 10,
            "alarm.message": 200,
            "alarm.last_occurrence": 100,
            "alarm.cause.service": 100,
        }

        return datasearch.COLUMN_PROPERTIES(
            label=self.default_columns.get(pi.path, field.capitalize()),
            headerTitle=header_tooltips.get(pi.path, False),
            name=field,
            index=field,
            hidden=pi.path in self._hidden_fields,
            sortable=True,
            align="left" if pi.path == "alarm.message" else "center",
            width=widths.get(pi.path, 50)
        )

    def _get_default_cells(self, obj, search):
        cells = datasearch.DataSearch._get_default_cells(self, obj, search)
        cells["_criteria"] = Criterion("alarm.alarmid", "=", obj[0])
        return cells

    def _get_dataset(self):
        return template.PrewikkaTemplate(__name__, "templates/alarm.mak").dataset()

    def _set_common(self, dataset):
        datasearch.DataSearch._set_common(self, dataset)
        dataset["show_closed_alarms"] = env.request.parameters["show_closed_alarms"]

    @view.route("/alarms/update_status", methods=["POST"], permissions=[N_("ALARM_ALTER")])
    def update_status(self):
        status = int(env.request.parameters["status"])

        criteria = Criterion()
        for i in env.request.parameters.getlist("criteria", type=utils.json.loads):
            criteria |= i

        if criteria:
            statuses = env.dataprovider.get_path_info("alarm.acknowledgment").value_accept

            rows = env.dataprovider.query(["alarm.cause.id", "alarm.acknowledgment"], criteria)
            env.dataprovider.update({"alarm.acknowledgment": status}, criteria)
            for cause_id, previous_status in rows:
                if status == previous_status:
                    continue

                env.dataprovider.insert({
                    "alarm.history.author": env.request.user.name,
                    "alarm.history.time": utils.timeutil.utcnow(),
                    "alarm.history.message": "Changed acknowledgment status from '%s' to '%s'" % (statuses[previous_status].label, statuses[status].label),
                    "alarm.history.value": statuses[status].label,
                    "alarm.history.type": "Acknowledgment change state"
                }, Criterion("alarm.cause.id", "=", cause_id))
            env.log.info("Changed alarm status to {0} with criteria \"{1}\"".format(statuses[status].label, criteria))

            return response.PrewikkaResponse({"type": "reload", "target": ".commonlisting"}).add_notification(_("Updated alarm status"))

    @hookmanager.register("HOOK_DATASEARCH_ALARM_ACTION")
    def add_acknowledgment_action(self):
        statuses = env.dataprovider.get_path_info("alarm.acknowledgment").value_accept
        options = [resource.HTMLNode("option", _(status.label), value=text_type(status.value)) for status in statuses]
        sel = resource.HTMLNode("select", *options, form="datasearch_grid_form", name="status", _class="status form-control")
        but = resource.HTMLNode("button", _("Update"), type="submit", form="datasearch_grid_form",
                                formmethod="POST", formaction=url_for("AlarmDataSearch.update_status"), _class="status btn btn-warning needone")
        return resource.HTMLNode("div", sel, but, _class="form-group")

    @hookmanager.register("HOOK_DATASEARCH_ALARM_EXTRA_DATA")
    def add_impact_data(self, results):
        if not results:
            return {}

        ids = [values[0] for values in results]
        ret = {alarmid: [] for alarmid in ids}
        criteria = functools.reduce(lambda x, y: x | y, (Criterion("alarm.alarmid", "=", alarmid) for alarmid in ids))
        for alarmid, service in env.dataprovider.query(["alarm.alarmid", "alarm.impact.service.name"], criteria):
            if service:
                ret[alarmid].append(service)

        return ret

    @hookmanager.register("HOOK_DATASEARCH_ALARM_EXTRA_COLUMN", _order=0)
    def add_impact_column(self):
        name = _("Impact")
        return (
            utils.AttrObj(label=name, name=name, index=name, width=50, position="right"),
            env.dataprovider.get_path_info("alarm.impact.service.name"),
            lambda row, extradata: extradata[0][row["alarm.alarmid"]]
        )

    @hookmanager.register("HOOK_RISKOVERVIEW_DATA", _order=3)
    def _set_alarms_summary(self):
        parameters = env.request.menu_parameters  # this is useful for the MSSP page (with the datasource parameter)

        alarms = collections.OrderedDict([
            (("CRITICAL", "DOWN"), utils.AttrObj(count=0, title=_("Critical/Down"), label="label-danger")),
            (("WARNING",), utils.AttrObj(count=0, title=_("Warning"), label="label-warning")),
            (("OK", "UP"), utils.AttrObj(count=0, title=_("OK/Up"), label="label-success")),
            (("UNKNOWN", "UNREACHABLE"), utils.AttrObj(count=0, title=_("Unknown/Unreachable"), label="label-default"))
        ])
        for states, obj in alarms.items():
            obj.criteria = functools.reduce(lambda x, y: x | y, (Criterion("alarm.current_state.name", "=", state) for state in states))

        results = env.dataprovider.query(['alarm.current_state.name/group_by', 'count(alarm.alarmid)'],
                                         env.request.menu.get_criteria())
        for state, count in results:
            for states in alarms:
                if state in states:
                    alarms[states].count += count
                    break

        data = []
        for obj in alarms.values():
            data.append(
                resource.HTMLNode("a", localization.format_number(obj.count, short=True),
                                  title=obj.title, _class="label " + obj.label,
                                  href=url_for("AlarmDataSearch.forensic", criteria=obj.criteria, **parameters))
            )

        return utils.AttrObj(
            name="alarms",
            title=resource.HTMLNode("a", _("Alarms"), href=url_for("AlarmDataSearch.forensic", **parameters)),
            data=data
        )
