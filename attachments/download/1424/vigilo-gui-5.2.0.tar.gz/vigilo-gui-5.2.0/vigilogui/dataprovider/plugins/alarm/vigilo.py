# -*- coding: utf-8 -*-
# Copyright (C) 2019-2020 CS GROUP - France. All Rights Reserved.
# Author: François Poirotte <francois.poirotte@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

from __future__ import absolute_import, division, print_function, unicode_literals

import datetime

from prewikka import database, dataprovider, error, usergroup
from prewikka.dataprovider.helpers.sql import SQLBuilder, SQLTable

from vigilogui import version


_CORREVENT = SQLTable("vigilo_correvent", pkey=("idcorrevent",))
_CORREVENT_DURATION = SQLTable("vigilo_guieventduration")
_EVENT = SQLTable("vigilo_event", pkey=("idevent",))
_MASKED_EVENT = SQLTable("vigilo_event")
_EVENT_HISTORY = SQLTable("vigilo_eventhistory")
_EVENTS_AGGREGATE = SQLTable("vigilo_eventsaggregate")
_CURR_STATE = SQLTable("vigilo_statename")
_PEAK_STATE = SQLTable("vigilo_statename")
_INIT_STATE = SQLTable("vigilo_statename")
# HACK: the UNION sub-query is hard-coded here to ease SQLBuilder's job
_SUPITEM = SQLTable("(SELECT idhost AS idsupitem, name, address, NULL as servicename FROM vigilo_host "
                    "UNION ALL SELECT idservice AS idsupitem, name, address, servicename FROM vigilo_lowlevelservice JOIN vigilo_host USING (idhost))")
_SERVICE = SQLTable("vigilo_highlevelservice")
_IMPACTED_PATH = SQLTable("vigilo_impactedpath")
_IMPACTED_HLS = SQLTable("vigilo_impactedhls")

_VIGILO_FIELDS_MAP = {
    "alarm.alarmid": (_CORREVENT, "idcorrevent"),
    "alarm.eventid": (_EVENT, "idevent"),
    "alarm.message": (_EVENT, "message"),
    "alarm.first_occurrence": (_CORREVENT, "timestamp_active"),
    "alarm.last_occurrence": (_EVENT, "timestamp"),
    "alarm.duration": (_CORREVENT_DURATION, "duration"),
    "alarm.priority": (_CORREVENT, "priority"),
    "alarm.occurrences": (_CORREVENT, "occurrence"),
    "alarm.acknowledgment": (_CORREVENT, "ack"),

    "alarm.cause.host.name": (_SUPITEM, "name"),
    "alarm.cause.host.address": (_SUPITEM, "address"),
    "alarm.cause.service": (_SUPITEM, "servicename"),
    "alarm.cause.id": (_CORREVENT, "idcause"),

    # FIXME: this path is not real but is necessary so that the JOINs
    #        built by the SQL builder work properly
    "alarm.idsupitem": (_EVENT, "idsupitem"),

    "alarm.current_state.id": (_EVENT, "current_state"),
    "alarm.current_state.name": (_CURR_STATE, "statename"),
    "alarm.current_state.rank": (_CURR_STATE, "order"),

    "alarm.initial_state.id": (_EVENT, "initial_state"),
    "alarm.initial_state.name": (_INIT_STATE, "statename"),
    "alarm.initial_state.rank": (_INIT_STATE, "order"),

    "alarm.peak_state.id": (_EVENT, "peak_state"),
    "alarm.peak_state.name": (_PEAK_STATE, "statename"),
    "alarm.peak_state.rank": (_PEAK_STATE, "order"),

    "alarm.history.author": (_EVENT_HISTORY, "username"),
    "alarm.history.time": (_EVENT_HISTORY, "timestamp"),
    "alarm.history.message": (_EVENT_HISTORY, "text"),
    "alarm.history.type": (_EVENT_HISTORY, "type_action"),
    "alarm.history.value": (_EVENT_HISTORY, "value"),

    "alarm.impact.path.id": (_IMPACTED_PATH, "idpath"),
    "alarm.impact.service.id": (_SERVICE, "idservice"),
    "alarm.impact.service.name": (_SERVICE, "servicename"),

    "alarm.masked_event.id": (_MASKED_EVENT, "idevent"),
}


class VigiloAlarmPlugin(dataprovider.DataProviderBackend):
    type = "alarm"
    plugin_name = "Vigilo Alarm Plugin"
    plugin_version = version.__version__
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Plugin for fetching alarms from Vigilo's database")

    TYPE_OPERATOR_MAPPING = {
        datetime.datetime: ("=", "!=", "<", ">", "<=", ">="),
        datetime.timedelta: ("=", "!=", "<", ">", "<=", ">="),
        int: ("=", "!=", "<", ">", "<=", ">="),
        text_type: ("=", "=*", "!=", "!=*", "~", "~*", "!~", "!~*", "<>", "<>*", "!<>", "!<>*"),
    }

    def __init__(self):
        dataprovider.DataProviderBackend.__init__(self)

        conf = env.config.alarm
        if not conf or conf.get_instance_name().lower() != "vigilo":
            raise error.PrewikkaUserError(N_("Missing configuration"),
                                          N_("Could not connect to Vigilo: plugin not configured."))

        settings = {"host": "localhost", "name": "vigilo", "user": "vigilo", "type": "pgsql"}
        settings.update(conf)
        self.db = database.Database(settings)

        joins = [
            ((_CORREVENT, "idcause"), (_EVENT, "idevent")),
            ((_CORREVENT, "idcorrevent"), (_CORREVENT_DURATION, "idcorrevent")),
            ((_EVENT, "idsupitem"), (_SUPITEM, "idsupitem")),
            ((_EVENT, "current_state"), (_CURR_STATE, "idstatename")),
            ((_EVENT, "initial_state"), (_INIT_STATE, "idstatename")),
            ((_EVENT, "peak_state"), (_PEAK_STATE, "idstatename")),
            ((_EVENT, "idevent"), (_EVENT_HISTORY, "idevent")),
            ((_EVENT, "idsupitem"), (_IMPACTED_PATH, "idsupitem")),
            ((_IMPACTED_PATH, "idpath"), (_IMPACTED_HLS, "idpath")),
            ((_IMPACTED_HLS, "idhls"), (_SERVICE, "idservice")),
            ((_CORREVENT, "idcorrevent"), (_EVENTS_AGGREGATE, "idcorrevent")),
            ((_EVENTS_AGGREGATE, "idevent"), (_MASKED_EVENT, "idevent")),
        ]
        tables = [_CORREVENT, _CORREVENT_DURATION, _EVENT, _EVENT_HISTORY, _CURR_STATE, _INIT_STATE, _PEAK_STATE, _SUPITEM, _IMPACTED_PATH, _IMPACTED_HLS, _SERVICE, _EVENTS_AGGREGATE, _MASKED_EVENT]
        self._sql_builder = SQLBuilder(_VIGILO_FIELDS_MAP, tables, joins, True, self.db, ("alarm.first_occurrence", "alarm.last_occurrence"))

    @usergroup.permissions_required(["ALARM_VIEW"])
    def get_values(self, paths, criteria, distinct=False, limit=-1, offset=0):
        query = self._sql_builder.build_query(paths, criteria, distinct=distinct, limit=limit, offset=offset)
        return dataprovider.QueryResults(self.db.query(query))

    @usergroup.permissions_required(["ALARM_ALTER"])
    def update(self, data, criteria):
        return self._sql_builder.execute_update(data, criteria)

    @usergroup.permissions_required(["ALARM_ALTER"])
    def insert(self, data, criteria):
        return self._sql_builder.execute_insert(data, criteria)
