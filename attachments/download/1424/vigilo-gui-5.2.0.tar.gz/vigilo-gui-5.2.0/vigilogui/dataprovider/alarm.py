# -*- coding: utf-8 -*-
# Copyright (C) 2019-2020 CS GROUP - France. All Rights Reserved.
# Author: François Poirotte <francois.poirotte@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

from __future__ import absolute_import, division, print_function, unicode_literals

import datetime

from prewikka import hookmanager, renderer
from prewikka.dataprovider import PathValue
from prewikka.dataprovider.pathparser import PathParser

from vigilogui import version

_ALARM_PATHS = {
    "alarm": {
        "alarmid": int,
        "eventid": int,
        "message": text_type,
        "acknowledgment": int,
        "first_occurrence": datetime.datetime,
        "last_occurrence": datetime.datetime,
        "duration": datetime.timedelta,
        "priority": int,
        "occurrences": int,
    },
    "alarm.cause": {
        "id": int,
        "service": text_type,
    },
    "alarm.cause.host": {
        "name": text_type,
        "address": text_type,
    },
    "alarm.initial_state": {
        "id": int,
        "name": text_type,
        "rank": int,
    },
    "alarm.peak_state": {
        "id": int,
        "name": text_type,
        "rank": int,
    },
    "alarm.current_state": {
        "id": int,
        "name": text_type,
        "rank": int,
    },
    "alarm.history": {
        "author": text_type,
        "time": datetime.datetime,
        "message": text_type,
        "value": text_type,
        "type": text_type
    },
    "alarm.impact.service": {
        "name": text_type,
    },
    "alarm.masked_event": {
        "id": int,
    },
}


class AlarmAPI(PathParser):
    plugin_name = "Alarm API"
    plugin_version = version.__version__
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Provides an API to fetch alarms from a NOC")
    dataprovider_label = N_("Alarms")

    def __init__(self):
        PathParser.__init__(self, _ALARM_PATHS, ("first_occurrence", "last_occurrence"))
        hookmanager.register("HOOK_WEBSERVICE_SCOPES", ["ALARM_VIEW"])

    def get_common_paths(self, index=False):
        return [
            (N_("State"), "alarm.current_state.name"),
            (N_("Message"), "alarm.message"),
            (N_("Priority"), "alarm.priority"),
            (N_("First occurrence"), "alarm.first_occurrence"),
            (N_("Last occurrence"), "alarm.last_occurrence"),
            (N_("Host"), "alarm.cause.host.name"),
            (N_("IP"), "alarm.cause.host.address"),
            (N_("Service"), "alarm.cause.service"),
        ]

    def _get_path_values(self, path):
        if path.endswith("state.name"):
            return [
                PathValue(value="OK", label=N_("OK"), color=renderer.GREEN_STD),
                PathValue(value="UP", label=N_("Up"), color=renderer.GREEN_STD),
                PathValue(value="WARNING", label=N_("Warning"), color=renderer.ORANGE_STD),
                PathValue(value="DOWN", label=N_("Down"), color=renderer.RED_STD),
                PathValue(value="CRITICAL", label=N_("Critical"), color=renderer.RED_STD),
                PathValue(value="UNKNOWN", label=N_("Unknown"), color=renderer.GRAY_STD),
                PathValue(value="UNREACHABLE", label=N_("Unreachable"), color=renderer.GRAY_STD),
            ]
        elif path == "alarm.acknowledgment":
            return [
                PathValue(value=0, label=N_("new")),
                PathValue(value=1, label=N_("acknowledged")),
                PathValue(value=2, label=N_("closed")),
            ]

    @hookmanager.register("HOOK_TICKET_CONDITIONS")
    def _ticket_conditions(self):
        return "alarm", [
            ("alarm.cause.host.name", N_("Host")),
            ("alarm.cause.service", N_("Service")),
        ]
