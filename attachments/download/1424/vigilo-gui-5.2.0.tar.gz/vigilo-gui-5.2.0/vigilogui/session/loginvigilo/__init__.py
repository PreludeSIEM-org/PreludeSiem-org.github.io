# Copyright (C) 2018-2020 CS GROUP - France. All Rights Reserved.
# Author: Thomas Andrejak <thomas.andrejak@c-s.fr>
#
# This file is part of the Vigilo GUI program.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

""" Login/password authentication module with Vigilo support"""

from __future__ import absolute_import, division, print_function, unicode_literals

import random
import requests
import string
import subprocess

from prewikka import hookmanager, session
from prewikka.session import loginform
from vigilogui import version


class LoginVigiloSession(loginform.LoginFormSession):
    plugin_name = "Vigilo NMS authentication"
    plugin_author = version.__author__
    plugin_license = version.__license__
    plugin_version = version.__version__
    plugin_copyright = version.__copyright__
    plugin_description = N_("Login/Password authentication with Vigilo NMS")
    plugin_locale = version.__locale__

    def init(self, config):
        self.auth_url = config.auth_url
        self.update_url = config.update_url
        self.cookie_name = config.get("cookie_name", "authtkt")
        self._auth_header = config.get("http_auth_header", "Auth-User")

    def get_user_info(self, request):
        login = request.arguments.get("_login", None)
        if not login:
            return None

        return session.SessionUserInfo(login, request.arguments.get("_password", ""))

    @hookmanager.register('HOOK_SESSION_CREATE')
    def _vigilo_set_session(self, user):
        info = self.get_user_info(env.request.web)
        if not info:
            return

        env.request.web.arguments.pop("_login", None)
        env.request.web.arguments.pop("_password", "")
        s = requests.Session()
        s.request('POST', self.auth_url, headers={self._auth_header: info.login})
        val = s.cookies.get_dict().get(self.cookie_name)
        if val:
            env.request.web.add_cookie(self.cookie_name, val, expires=self._expiration * 3, httponly=True)

    @hookmanager.register('HOOK_SESSION_UPDATE')
    def _vigilo_update_session(self, user):
        cookie = env.request.web.input_cookie.get(self.cookie_name)
        if not cookie:
            return

        requests.get(self.update_url, cookies={self.cookie_name: cookie.value})
        env.request.web.add_cookie(self.cookie_name, cookie.value, expires=self._expiration * 3, httponly=True)

    @hookmanager.register('HOOK_SESSION_DELETE')
    def _vigilo_delete_session(self, user):
        env.request.web.delete_cookie(self.cookie_name)

    @hookmanager.register('HOOK_USER_CREATE')
    def _user_created(self, user):
        # Generate a random password for the user inside Vigilo.
        password = "".join(random.choice(string.ascii_lowercase) for i in range(20))
        subprocess.check_call([
            "sudo", "vigilo-cli", "user-create",
            "--fullname", "",
            "--email", user.name,
            "--password", password,
            user.name
        ])
        subprocess.check_call(["sudo", "vigilo-cli", "usergroup-include", "managers", user.name])

    @hookmanager.register('HOOK_USER_DELETE')
    def _user_deleted(self, user):
        subprocess.check_call(["sudo", "vigilo-cli", "user-delete", user.name])

    def logout(self, request):
        return session.Session.logout(self, request)
