# -*- coding: utf-8 -*-
"""Ce module contient des migrations factices."""
