# -*- coding: utf-8 -*-
# Copyright (C) 2006-2020 CS GROUP - France
# License: GNU GPL v2 <http://www.gnu.org/licenses/gpl-2.0.html>
"""
Ce module comprend un script qui permet d'administrer Vigilo
(gestion des utilisateurs, des groupes d'utilisateurs, des permissions)
depuis la ligne de commandes.
"""
