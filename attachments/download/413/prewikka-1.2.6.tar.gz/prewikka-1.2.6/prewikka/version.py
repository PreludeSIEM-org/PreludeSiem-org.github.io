__version_info__ = (1, 2, 6)
__version__ = ".".join(str(i) for i in __version_info__)
__branch__ = "1.2"
__author__ = "Prelude Team"
__license__ = "GPL"
__copyright__ = "CSSI"
