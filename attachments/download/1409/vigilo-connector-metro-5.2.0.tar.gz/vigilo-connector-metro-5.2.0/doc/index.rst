######################
Vigilo connector-metro
######################

Le module connector-metro a pour fonction de recevoir des données de métrologie
(généralement émises par le composant vigilo-connector-nagios) et de les
stocker dans une base de données circulaire (RRD).

Documentation disponible :

.. toctree::
   :maxdepth: 2

   admin


.. *****************
.. Indexes et tables
.. *****************
.. 
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
