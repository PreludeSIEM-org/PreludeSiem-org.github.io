#########
Collector
#########

Le Collector est le composant de Vigilo responsable de la collecte SNMP
optimisée.

Documentation disponible :

.. toctree::
   :maxdepth: 2

   dev


.. *****************
.. Indexes et tables
.. *****************
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
