import json

from prewikka.database import SQLScript
from prewikkaupdatedb.common.criteria400 import convert_criteria


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("4.0", "0")
    branch = "4.1"
    version = "0"

    def run(self):
        for id_, value in self.db.query("SELECT id, value FROM Prewikka_Filter"):
            criteria = json.dumps(convert_criteria(json.loads(value)))
            self.db.query("UPDATE Prewikka_Filter SET value = %s WHERE id = %s",
                          criteria, id_)
