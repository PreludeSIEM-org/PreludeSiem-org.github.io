from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("3.0", "0")
    branch = "3.1"
    version = "0"

    def run(self):
        # No schema changes.
        pass
