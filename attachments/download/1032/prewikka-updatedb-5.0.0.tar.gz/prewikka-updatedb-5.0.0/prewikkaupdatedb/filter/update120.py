from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("1.2", "0")
    branch = "3.0"
    version = "0"

    def run(self):
        # No schema changes.
        pass
