import json
import re

from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("3.1", "0")
    branch = "4.0"
    version = "0"

    def run(self):
        filters = []

        for id_, userid, name, comment, formula, type_ in self.db.query("SELECT id, userid, name, comment, formula, type FROM Prewikka_Filter"):
            formula = re.sub("AND|and", "&&", re.sub("OR|or", "||", formula))
            criterion = Converter(formula).get_value()
            elements = {}
            for elem, path, op, value in self.db.query("SELECT name, path, operator, value FROM Prewikka_Filter_Criterion WHERE id = %s", id_):
                elements[elem] = SingleCriterion(path, op, value)

            if not isinstance(criterion, Criterion):
                criterion = elements[criterion]

            f = {}
            if type_ == "generic":
                for t in ("alert", "heartbeat"):
                    f[t] = criterion.resolve(elements, t)
            else:
                f[type_] = criterion.resolve(elements, type_)

            filters.append((userid, name, comment, json.dumps(f)))

        self.query("""
ALTER TABLE Prewikka_Filter RENAME TO Prewikka_Filter_Temp;

CREATE TABLE Prewikka_Filter (
        id BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
        userid VARCHAR(32) NOT NULL,
        name VARCHAR(64) NOT NULL,
        description TEXT NULL,
        value TEXT NOT NULL
) ENGINE=InnoDB;
        """)

        if filters:
            self.db.query("INSERT INTO Prewikka_Filter (userid, name, description, value) "
                          "VALUES %s", filters)

        self.query("""
DROP TABLE Prewikka_Filter_Criterion;
DROP TABLE Prewikka_Filter_Temp;

CREATE UNIQUE INDEX prewikka_filter_index_login_name ON Prewikka_Filter (userid, name);
        """)


class Criterion(object):
    def __init__(self, left, operator, right):
        self.left, self.operator, self.right = left, operator, right

    def resolve(self, elements, typ):
        l = []
        for operand in (self.left, self.right):
            if isinstance(operand, Criterion):
                l.append(operand.resolve(elements, typ))
            else:
                l.append(elements[operand].resolve(elements, typ))

        return {"__prewikka_class__": ("Criterion", [l[0], self.operator, l[1]])}


class SingleCriterion(object):
    def __init__(self, left, operator, right):
        self.left, self.operator, self.right = left, operator, right

    def resolve(self, elements, typ):
        return {"__prewikka_class__": ("Criterion", ["%s.%s" % (typ, self.left), self.operator, self.right])}


class Converter(object):
    # Adapted from Eli Bendersky (eliben@gmail.com)
    # License: this code is in the public domain
    def __init__(self, expr):
        self._iter = iter(re.findall("\s*(\w+|\(|\)|&&|\|\|)", expr))
        self._next_token()

    def _next_token(self):
        self.current = next(self._iter, None)

    def _compute_atom(self):
        token = self.current
        if token == '(':
            self._next_token()
            val = self.get_value()
            if self.current != ')':
                raise RuntimeError('unmatched "("')
            self._next_token()
            return val
        elif token is None:
            raise RuntimeError('source ended unexpectedly')
        elif token in ('&&', '||'):
            raise RuntimeError('expected an atom, not an operator "%s"' % token)
        else:
            self._next_token()
            return token

    def get_value(self, min_prec=1):
        left = self._compute_atom()

        while True:
            op = self.current
            prec = {'||': 1, '&&': 2}.get(op)
            if not prec or prec < min_prec:
                break

            self._next_token()
            right = self.get_value(prec + 1)
            left = Criterion(left, op, right)

        return left
