from prewikka.database import SQLScript


class SQLUpdate(SQLScript):
    type = "branch"
    from_branch = ("4.1", "2")
    branch = "5.0"
    version = "0"

    def run(self):
        # No schema changes.
        pass
