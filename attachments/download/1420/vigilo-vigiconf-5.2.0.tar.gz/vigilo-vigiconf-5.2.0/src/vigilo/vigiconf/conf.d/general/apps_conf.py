# vim: fileencoding=utf-8 sw=4 ts=4 et ai
# Copyright (C) 2011-2020 CS GROUP - France
# License: GNU GPL v2 <http://www.gnu.org/licenses/gpl-2.0.html>
# permet de modifier la configuration des applications Vigilo

apps_conf.update({
    # exemple: configuration du timeout pour l'application nagios.
    #'nagios': {"timeout": 60}
    })

# vim:set expandtab tabstop=4 shiftwidth=4:
