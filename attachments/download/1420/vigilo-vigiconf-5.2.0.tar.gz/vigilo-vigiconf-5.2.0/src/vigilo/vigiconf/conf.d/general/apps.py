# vim: fileencoding=utf-8 sw=4 ts=4 et ai
# Copyright (C) 2011-2020 CS GROUP - France
# License: GNU GPL v2 <http://www.gnu.org/licenses/gpl-2.0.html>

apps.update([
        "nagios",
        "connector-metro",
        "collector",
        "perfdata",
        "vigirrd",
        ])

confid = "$Rev$"[6:-2]

# vim:set expandtab tabstop=4 shiftwidth=4:
