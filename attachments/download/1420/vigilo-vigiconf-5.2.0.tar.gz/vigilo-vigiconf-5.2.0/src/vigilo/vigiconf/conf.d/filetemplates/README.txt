In this folder, you can override the application templates:

 * Create a directory with the application name
 * Copy the file you want to override from the application's "template"
   directory into this directory
 * Modify it to suit your needs

