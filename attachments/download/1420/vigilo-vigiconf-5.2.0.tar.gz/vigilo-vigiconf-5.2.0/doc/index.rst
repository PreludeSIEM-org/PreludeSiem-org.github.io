########
VigiConf
########

VigiConf est le centre de configuration de Vigilo.

Documentation disponible :

..  toctree::
    :maxdepth: 2

    admin
    dev

.. : "suptests" est inclus et ne doit pas être référencé dans une TOC visible.
.. : On l'inclus dans une table cachée pour éviter un avertissement de Sphinx.

.. toctree::
   :hidden:

   suptests


.. *****************
.. Indexes et tables
.. *****************
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`


.. vim: set tw=79 :
