#!/bin/sh -x
javac -cp /usr/share/java/PreludeEasy.jar test.java
