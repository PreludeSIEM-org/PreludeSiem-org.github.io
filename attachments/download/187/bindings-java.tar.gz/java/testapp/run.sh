#!/bin/bash
java -cp /usr/share/java/PreludeEasy.jar:. test
